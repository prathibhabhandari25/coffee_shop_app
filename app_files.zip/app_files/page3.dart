import 'package:flutter/material.dart';
import 'package:flutter_project2/home2.dart';
import 'package:flutter_project2/shcoltabbar.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:expandable_text/expandable_text.dart';

class Page3 extends StatefulWidget {
  const Page3({super.key});

  @override
  State<Page3> createState() => _Page3State();
}

class _Page3State extends State<Page3> {
  int selectedContainerIndex = -1;
  int selectedContainerIndex2 = -1;

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Container(
              height: screenHeight * (3 / 4),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(
                      'assets/pngwing.com (6).png'), // Replace with your image path
                  fit: BoxFit.cover,
                  // Adjust the BoxFit as needed
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 40),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      // Navigate to the second page on tap
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => Home()),
                      );
                    },
                    child: Container(
                      height: 50,
                      width: 50,
                      child: Icon(Icons.arrow_back, color: Colors.black),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: Colors.black, width: 2),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 295,
                  ),
                  Container(
                      height: 50,
                      width: 50,
                      child: Icon(
                        Icons.favorite,
                        color: Colors.black,
                      ),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: Colors.black, width: 1))),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 500),
              child: Container(
                height: 500,
                width: 600,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(60),
                        topRight: Radius.circular(60))),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 20, left: 20),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Latte',
                            style: GoogleFonts.poppins(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                                color: Colors.black),
                          ),
                        ],
                      ),
                    ),
                    Gap(10),
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Container(
                        child: Row(
                          children: [
                            Icon(Icons.star, size: 20),
                            Text('4.3',
                                style: GoogleFonts.poppins(
                                    fontSize: 19,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black)),
                            Gap(15),
                            Text('(3453 Reviews)',
                                style: GoogleFonts.poppins(
                                    fontSize: 19,
                                    fontWeight: FontWeight.w300,
                                    color: Colors.black))
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: ExpandableText(
                        'Caffè latte  in English, is a coffee drink of Italian origin made with espresso and steamed milk. Variants include the chocolate-flavored mocha or replacing the coffee with another beverage base such as masala chai (spiced Indian tea), mate, matcha, turmeric or rooibos; alternatives to milk, such as soy milk or almond milk.',
                        expandText: 'Read more',
                        collapseText: 'show less',
                        maxLines: 3,
                        linkColor: Colors.blue,
                        style: GoogleFonts.poppins(
                            fontSize: 10,
                            color: Colors.black,
                            fontWeight: FontWeight.w400),
                      ),
                    ),
                    Gap(20),
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Text(
                        'size',
                        style: GoogleFonts.poppins(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Row(
                        children: [
                          buildContainer('S', 0),
                          Gap(30),
                          buildContainer('M', 1),
                          Gap(30),
                          buildContainer('L', 2),
                        ],
                      ),
                    ),
                    Gap(20),
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Text(
                        'Units',
                        style: GoogleFonts.poppins(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Row(
                        children: [
                          buildContainer2('-', 0),
                          Gap(30),
                          buildContainer2('M', 1),
                          Gap(30),
                          buildContainer2('+', 2),
                        ],
                      ),
                    ),
                    Gap(20),
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Row(
                        children: [
                          Text(
                            '\$25.00',
                            style: GoogleFonts.poppins(
                                fontSize: 25,
                                color: Colors.black,
                                fontWeight: FontWeight.bold),
                          ),
                          Gap(100),
                          GestureDetector(
                            onTap: () {
                              // Navigate to the second page on tap
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => CustomShapedTabbar()),
                              );
                            },
                            child: Container(
                              height: 50,
                              width: 180,
                              child: Center(
                                child: Text(
                                  'Buy Now',
                                  style: GoogleFonts.poppins(
                                      fontSize: 25,
                                      fontWeight: FontWeight.normal,
                                      color: Colors.white),
                                ),
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(25),
                                color: const Color.fromARGB(255, 242, 160, 38),
                              ),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildContainer(String label, int index) {
    bool isSelected = selectedContainerIndex == index;

    return GestureDetector(
      onTap: () {
        // When a container is tapped, update the selectedContainerIndex
        setState(() {
          if (isSelected) {
            selectedContainerIndex = -1; // Unselect the container
          } else {
            selectedContainerIndex = index; // Select the container
          }
        });
      },
      child: Container(
        height: 50,
        width: 50,
        decoration: BoxDecoration(
          color: isSelected ? Colors.orange : Colors.grey,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Center(
          child: Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: 20,
              color: Colors.white,
              fontWeight: FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }

  Widget buildContainer2(String label, int index) {
    bool isSelected = selectedContainerIndex2 == index;

    return GestureDetector(
      onTap: () {
        // When a container is tapped, update the selectedContainerIndex
        setState(() {
          if (isSelected) {
            selectedContainerIndex2 = -1; // Unselect the container
          } else {
            selectedContainerIndex2 = index; // Select the container
          }
        });
      },
      child: Container(
        height: 50,
        width: 50,
        decoration: BoxDecoration(
          color: isSelected ? Colors.orange : Colors.grey,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Center(
          child: Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: 20,
              color: Colors.white,
              fontWeight: FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_project2/Intro_screen2.dart';
import 'package:lottie/lottie.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';


class Animation1 extends StatefulWidget {
  const Animation1({super.key});

  @override
  State<Animation1> createState() => _Animation1State();
}

class _Animation1State extends State<Animation1> {
  void initState() {
    Future.delayed(
      Duration(seconds: 10),
      () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Intro_Screen2()),
        );
      },
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: ListView(
          children: [
            // Load a Lottie file from your assets
            Lottie.asset('assets/Animation - 1700626744678.json'),

            Padding(
              padding: const EdgeInsets.only(left: 160),
              child: LoadingAnimationWidget.discreteCircle(
                  color: Colors.white,
                  size: 60,
                  secondRingColor: Colors.brown,
                  thirdRingColor: Color.fromARGB(255, 224, 188, 174)),
            ),

            // // Load a Lottie file from a remote url
            // // Lottie.network(
            //     'https://raw.githubusercontent.com/xvrh/lottie-flutter/master/example/assets/Mobilo/A.json'),

            // // Load an animation and its images from a zip file
            // Lottie.asset('assets/lottiefiles/angel.zip'),
          ],
        ),
      ),
    );
  }
}

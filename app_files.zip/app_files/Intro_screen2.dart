import 'package:flutter/material.dart';
import 'package:flutter_project2/home2.dart';
import 'package:google_fonts/google_fonts.dart';

class Intro_Screen2 extends StatelessWidget {
  const Intro_Screen2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Stack(
          children: [
            Image.asset(
              'assets/p1.webp',
              height: 900,
              fit: BoxFit.cover,
            ),
            // Padding(
            //   padding: const EdgeInsets.only(top: 150, left: 40),
            //   child: Image.asset('assets/pngwing.com (10).png',
            //       height: 120, width: 900),
            // ),
            Padding(
              padding: const EdgeInsets.only(top: 560, left: 140),
              child: Column(
                // crossAxisAlignment: CrossAxisAlignment.center,

                children: [
                  Text(
                    'Good coffee,',
                    style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'Good mood,',
                    style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'Let it blend',
                    style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 700, left: 70),
              child: Text(
                'The best grain,the best roast the most powerful flavor',
                style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.normal),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 760, left: 80),
              child: GestureDetector(
                onTap: () {
                  // Navigate to the second page on tap
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Home()),
                  );
                },
                child: Container(
                  height: 50,
                  width: 250,
                  decoration: BoxDecoration(
                      color: Colors.orange,
                      borderRadius: BorderRadius.circular(30)),
                  child: Center(
                    child: Text(
                      'Get Started',
                      style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontSize: 25,
                          fontWeight: FontWeight.normal),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 100, left: 120),
              child: Container(
                height: 150,
                width: 150,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: Colors.orange),
                child: Column(
                  children: [
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                          // borderRadius: BorderRadius.circular(100),
                          ),
                      child: Image.asset(
                        'assets/pngwing.com (17).png',
                      ),
                    ),
                    Text(
                      'CAFE COFFEE',
                      style: GoogleFonts.poppins(
                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
